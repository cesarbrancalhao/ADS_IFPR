--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 16.3 (Debian 16.3-1.pgdg120+1)
-- Dumped by pg_dump version 16.3 (Debian 16.3-1.pgdg120+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE coeus;
--
-- Name: coeus; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE coeus WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'en_US.utf8';


ALTER DATABASE coeus OWNER TO postgres;

\connect coeus

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: calculo_bottleneck(integer, integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.calculo_bottleneck(p_cpu_id integer, p_gpu_id integer) RETURNS text
    LANGUAGE plpgsql
    AS $$
DECLARE
    v_cpu RECORD;
    v_gpu RECORD;
    cpu_per_core NUMERIC;
    cpu_bottleneck NUMERIC;
    thread_bottleneck NUMERIC;
    gpu_bottleneck NUMERIC;
BEGIN
    SELECT * INTO v_cpu FROM cpu WHERE id = p_cpu_id;
    SELECT * INTO v_gpu FROM gpu WHERE id = p_gpu_id;

    IF v_cpu.id IS NULL OR v_gpu.id IS NULL THEN
        RETURN 'CPU ou GPU não encontrado';
    END IF;

    cpu_per_core := (v_cpu.totalbench * 0.77) / v_cpu.cores;

    cpu_bottleneck := FLOOR((cpu_per_core / (v_gpu.benchmark_score * 1.77)) * 100);
    thread_bottleneck := FLOOR((v_cpu.threadbench / (v_gpu.benchmark_score * 1.77)) * 100);
    gpu_bottleneck := FLOOR((v_cpu.totalbench * 0.77) / (v_gpu.benchmark_score * 1.77));

    RETURN FORMAT('GPU bottleneck: %s%%, CPU bottleneck: %s%%, Thread bottleneck: %s%%',
                  gpu_bottleneck::TEXT,
                  cpu_bottleneck::TEXT,
                  thread_bottleneck::TEXT);
END;
$$;


ALTER FUNCTION public.calculo_bottleneck(p_cpu_id integer, p_gpu_id integer) OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: cooler; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.cooler (
    id integer NOT NULL,
    name character varying(255),
    price numeric(10,2),
    fans integer,
    fan_speed integer,
    noise_level integer
);


ALTER TABLE public.cooler OWNER TO postgres;

--
-- Name: cooler_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.cooler_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.cooler_id_seq OWNER TO postgres;

--
-- Name: cooler_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.cooler_id_seq OWNED BY public.cooler.id;


--
-- Name: cpu; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.cpu (
    id integer NOT NULL,
    name character varying(255),
    cores integer,
    price numeric(10,2),
    totalbench integer,
    threadbench integer,
    tdp integer,
    socket character varying(50)
);


ALTER TABLE public.cpu OWNER TO postgres;

--
-- Name: cpu_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.cpu_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.cpu_id_seq OWNER TO postgres;

--
-- Name: cpu_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.cpu_id_seq OWNED BY public.cpu.id;


--
-- Name: gpu; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.gpu (
    id integer NOT NULL,
    name character varying(255),
    tdp integer,
    vram integer,
    benchmark_score integer,
    price numeric(10,2)
);


ALTER TABLE public.gpu OWNER TO postgres;

--
-- Name: gpu_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.gpu_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.gpu_id_seq OWNER TO postgres;

--
-- Name: gpu_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.gpu_id_seq OWNED BY public.gpu.id;


--
-- Name: hdd; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.hdd (
    id integer NOT NULL,
    name character varying(255),
    price numeric(10,2),
    reading_speed integer,
    storage_size integer
);


ALTER TABLE public.hdd OWNER TO postgres;

--
-- Name: hdd_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.hdd_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.hdd_id_seq OWNER TO postgres;

--
-- Name: hdd_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.hdd_id_seq OWNED BY public.hdd.id;


--
-- Name: motherboard; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.motherboard (
    id integer NOT NULL,
    name character varying(255),
    socket character varying(50),
    price numeric(10,2),
    sata_slots integer,
    nvme_slots integer,
    ram_slots integer,
    tdp integer
);


ALTER TABLE public.motherboard OWNER TO postgres;

--
-- Name: motherboard_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.motherboard_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.motherboard_id_seq OWNER TO postgres;

--
-- Name: motherboard_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.motherboard_id_seq OWNED BY public.motherboard.id;


--
-- Name: psu; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.psu (
    id integer NOT NULL,
    name character varying(255),
    wattage integer,
    price numeric(10,2),
    efficiency integer
);


ALTER TABLE public.psu OWNER TO postgres;

--
-- Name: psu_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.psu_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.psu_id_seq OWNER TO postgres;

--
-- Name: psu_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.psu_id_seq OWNED BY public.psu.id;


--
-- Name: ram; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.ram (
    id integer NOT NULL,
    name character varying(255),
    memory integer,
    frequency integer,
    price numeric(10,2)
);


ALTER TABLE public.ram OWNER TO postgres;

--
-- Name: ram_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.ram_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.ram_id_seq OWNER TO postgres;

--
-- Name: ram_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.ram_id_seq OWNED BY public.ram.id;


--
-- Name: cooler id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cooler ALTER COLUMN id SET DEFAULT nextval('public.cooler_id_seq'::regclass);


--
-- Name: cpu id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cpu ALTER COLUMN id SET DEFAULT nextval('public.cpu_id_seq'::regclass);


--
-- Name: gpu id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.gpu ALTER COLUMN id SET DEFAULT nextval('public.gpu_id_seq'::regclass);


--
-- Name: hdd id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.hdd ALTER COLUMN id SET DEFAULT nextval('public.hdd_id_seq'::regclass);


--
-- Name: motherboard id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.motherboard ALTER COLUMN id SET DEFAULT nextval('public.motherboard_id_seq'::regclass);


--
-- Name: psu id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.psu ALTER COLUMN id SET DEFAULT nextval('public.psu_id_seq'::regclass);


--
-- Name: ram id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ram ALTER COLUMN id SET DEFAULT nextval('public.ram_id_seq'::regclass);


--
-- Data for Name: cooler; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.cooler (id, name, price, fans, fan_speed, noise_level) FROM stdin;
\.
COPY public.cooler (id, name, price, fans, fan_speed, noise_level) FROM '$$PATH$$/3405.dat';

--
-- Data for Name: cpu; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.cpu (id, name, cores, price, totalbench, threadbench, tdp, socket) FROM stdin;
\.
COPY public.cpu (id, name, cores, price, totalbench, threadbench, tdp, socket) FROM '$$PATH$$/3399.dat';

--
-- Data for Name: gpu; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.gpu (id, name, tdp, vram, benchmark_score, price) FROM stdin;
\.
COPY public.gpu (id, name, tdp, vram, benchmark_score, price) FROM '$$PATH$$/3401.dat';

--
-- Data for Name: hdd; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.hdd (id, name, price, reading_speed, storage_size) FROM stdin;
\.
COPY public.hdd (id, name, price, reading_speed, storage_size) FROM '$$PATH$$/3403.dat';

--
-- Data for Name: motherboard; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.motherboard (id, name, socket, price, sata_slots, nvme_slots, ram_slots, tdp) FROM stdin;
\.
COPY public.motherboard (id, name, socket, price, sata_slots, nvme_slots, ram_slots, tdp) FROM '$$PATH$$/3411.dat';

--
-- Data for Name: psu; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.psu (id, name, wattage, price, efficiency) FROM stdin;
\.
COPY public.psu (id, name, wattage, price, efficiency) FROM '$$PATH$$/3407.dat';

--
-- Data for Name: ram; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.ram (id, name, memory, frequency, price) FROM stdin;
\.
COPY public.ram (id, name, memory, frequency, price) FROM '$$PATH$$/3409.dat';

--
-- Name: cooler_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.cooler_id_seq', 10, true);


--
-- Name: cpu_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.cpu_id_seq', 685, true);


--
-- Name: gpu_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.gpu_id_seq', 66, true);


--
-- Name: hdd_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.hdd_id_seq', 9, true);


--
-- Name: motherboard_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.motherboard_id_seq', 10, true);


--
-- Name: psu_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.psu_id_seq', 9, true);


--
-- Name: ram_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.ram_id_seq', 11, true);


--
-- Name: cooler cooler_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cooler
    ADD CONSTRAINT cooler_pkey PRIMARY KEY (id);


--
-- Name: cpu cpu_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cpu
    ADD CONSTRAINT cpu_pkey PRIMARY KEY (id);


--
-- Name: gpu gpu_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.gpu
    ADD CONSTRAINT gpu_pkey PRIMARY KEY (id);


--
-- Name: hdd hdd_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.hdd
    ADD CONSTRAINT hdd_pkey PRIMARY KEY (id);


--
-- Name: motherboard motherboard_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.motherboard
    ADD CONSTRAINT motherboard_pkey PRIMARY KEY (id);


--
-- Name: psu psu_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.psu
    ADD CONSTRAINT psu_pkey PRIMARY KEY (id);


--
-- Name: ram ram_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ram
    ADD CONSTRAINT ram_pkey PRIMARY KEY (id);


--
-- PostgreSQL database dump complete
--

